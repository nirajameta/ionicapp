import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';


@Component({
  selector: 'app-tab2',
  templateUrl: './tab2.page.html',
  styleUrls: ['./tab2.page.scss'],
})
export class Tab2Page implements OnInit {
  weartype:any;
  constructor(private router: Router) { }

  ngOnInit() {
    // this.user = {
    //   name: 'Simon Grimm',
    //   website: 'www.ionicacademy.com',
    //   address: {
    //     zip: 48149,
    //     city: 'Muenster',
    //     country: 'DE'
    //   },
    //   interests: [
    //     'Kids Wear', 'Men\'s Wear', 'Women\'s Wear'
    //   ]
    // };
  
  }
  gotoProduct(itemname){
    // let navigationExtras: NavigationExtras = {
    //   queryParams: {
    //     special: JSON.stringify(item)
    //   }
    // };
    //this.router.navigate(['tabs/tabs/tab2/details'], navigationExtras);
    //this.router.navigateByUrl('tabs/tabs/tab2/details');
    this.router.navigate(['tabs/tabs/tab2/details', {id: itemname}]);
  }

}
