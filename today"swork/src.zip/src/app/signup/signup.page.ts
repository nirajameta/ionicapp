import { Component, OnInit, ViewChild} from '@angular/core';
import { IonSlides } from '@ionic/angular';
import { NgForm } from '@angular/forms';
import { faCoffee } from '@fortawesome/free-solid-svg-icons';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ToastController } from '@ionic/angular';




@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {
  public ionicForm: FormGroup;
  public loginForm: FormGroup;
  isSubmitted = false;
  faCoffee = faCoffee;
  user:any;
  registrationData:any;
  password_type: string = 'password';
  
 
  @ViewChild('slides') slides: IonSlides;


  constructor(public formBuilder: FormBuilder, public toastController: ToastController) { }

  ngOnInit() {
    this.ionicForm = this.formBuilder.group({
      name: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      password: ['', [Validators.required, Validators.minLength(4)]],
    });

    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(4)]],
    });
  }

  async slideChanged() {
    await this.slides.getActiveIndex().then((index)=> {
      console.log(index);
    });
  }
  togglePasswordMode() {
    this.password_type = this.password_type === 'text' ? 'password' : 'text';
 }


  nextSlide(){
    this.slides.slideNext();
  }
  previousSlide(){
    this.slides.slidePrev();
  }
  
  get errorControl() {
    return this.ionicForm.controls;
  }

  async loginFormSubmit(){
    this.user = JSON.parse(localStorage.getItem('registerdd'));
    console.log(this.user);
    console.log(this.loginForm.value);
    if (this.user === null || this.user === undefined){
      console.log('not register yet');
      let toast = await this.toastController.create({
        message: 'Please Register before Login',
        duration: 3000,
        position: 'top'
      });
      toast.present();
    }
    if(this.loginForm.value.email == this.user.name &&  this.loginForm.value.password == this.user.password){
      console.log('dashboard');
    }
    else{
      let toast = await this.toastController.create({
        message: 'Either Username or Password is wrong',
        duration: 5000
      });
      toast.present();
    }
  
   }

  submitForm() {
    this.isSubmitted = true;
    if (!this.ionicForm.valid) {
      console.log('Please provide all the required values!');
      return false;
    } else {
      console.log(this.ionicForm.value);
      this.registrationData = localStorage.setItem('registerdd', JSON.stringify(this.ionicForm.value));

      //console.log(this.registrationData);
      console.log(localStorage.getItem('registerdd'));
      this.presentToast();
      // const toast = await this.toastController.create({
      //   message: 'Your settings have been saved.',
      //   duration: 2000
      // });
    }
  }

  async presentToast() {
    const toast = await this.toastController.create({
      message: 'You have Registered Successfully in localStorage',
      duration: 2000
    });
    toast.present();
  }
  // slidevalue(n){
  //   console.log('click on',n);
  // }

}
