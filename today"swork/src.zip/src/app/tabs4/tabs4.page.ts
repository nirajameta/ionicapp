import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabs4',
  templateUrl: './tabs4.page.html',
  styleUrls: ['./tabs4.page.scss'],
})
export class Tabs4Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
