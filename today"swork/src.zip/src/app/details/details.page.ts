import { Component, OnInit } from '@angular/core';
import datatable from '../data.json';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.page.html',
  styleUrls: ['./details.page.scss'],
})
export class DetailsPage implements OnInit {
  data: any;
  itemtitle:any;
  dataArray:any;
  catagory:any[];
  Users: any = datatable;
  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    // this.route.queryParams.subscribe(params => {
    //   if (params && params.special) {
    //     this.data = JSON.parse(params.special);
    //     console.log(this.data);
    //   }
    // });
    this.dataArray = this.Users.datas;
    this.data = this.route.params.subscribe(params => {
      this.itemtitle = params['id']; 
      console.log(this.itemtitle);
    });
  }
  segmentChanged(ev: any) {
    console.log('Segment changed', ev.detail.value);
  }

}
